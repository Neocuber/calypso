Decker
======
A multimedia sketchbook.

Windows Notes
-------------
- It may be necessary to adjust the "Microphone" setting in the "Privacy" control panel to "Allow apps to access your microphone" to enable audio recording.

Changelog
---------
v1.40:
- introduced the "like" operator.
v1.39:
- added dictionary conforming and raze-of-table to lil.
- generalized deck.remove[] to accept any widget.
- new example deck: puppeteer
v1.38:
- improved performance in readcsv[] and "by" clauses in queries.
- generalized rtext.cat[] to accept image interfaces.
- introduced image.scale[]
- compact slider arrows are visibly disabled at maximum value extents.
- transparent invisible buttons do not invert their backgrounds when clicked.
v1.37:
- introduce "underpaint mode" for drawing tools.
v1.36:
- bugfixes for GIF output (web) and event resolution in contraptions.
v1.35:
- added card title overlay while editing decks.
- generalized rtext.replace[] with a case-insensitive mode.
- improved GIF compression.
v1.34:
- all documentation now includes syntax highlighting for lil examples.
- introduced "rtext.replace[]".
- breaking: overhauled the lil `insert` syntax.
v1.33:
- generalized writexml[] to make formatting optional.
v1.32:
- the script profiler now shows a brief histogram of activity, rather than an instantaneous bar.
- introduced "app.show[]" and "app.print[]".
- introduced the "prod" operator.
- breaking: the "extract" query form no longer automatically de-lists count-1 lists, improving consistency.
- breaking: the "select","extract", and "update" query forms now permit repeated clauses in any order.
v1.31:
- loosened constraints on the Lil "%j" JSON parser to permit single-quoted string literals.
- introduced "pointer.down" and "pointer.up".
- introduced "rtext.split[delim rtext]".
- introduced "canvas.segment[img rect margin]".
v1.30:
- introduced `canvas.textsize[]` for measuring the dimensions of rtext.
- copying and pasting cards or widgets now transports custom fonts, as needed.
v1.29:
- misc bugfixes and usability refinements.
v1.28:
- introduced the "bits" interface.
- introduced "image.translate[]".
- generalized "image.merge[]" and "canvas.merge[]" to accept a configurable binary operator controlling the merge.
v1.27:
- introduced alignment guides for widget positioning and sizing.
- "first" and "keys" applied to functions now extract the function name and argument list, respectively.
- added ".hist" attribute to the image and sound interfaces.
v1.26:
- added support for enabling toolbars while in windowed mode.
- introduced "image.rotate[]".
- introduced "panic[]".
- generalized "eval[]" to permit importing the calling scope.
v1.25:
- added round-tripping between the Actions modal and generated button scripts.
- contraptions now have access to "deck" and "patterns" as globals.
- customized color palettes are now persisted with the deck.
- added "color" mode for manual drawing.
v1.24:
- introduced the %v and %q format patterns for "lil variable" and "lil quoted-string" parsing, respectively.
- introduced the brush[] global function and support for custom brushes throughout Decker.
v1.23:
- introduced button.shortcut.
- generalized lil format patterns to permit named fields.
v1.22:
- introduced import[] in lilt.
- introduced card/deck .copy[]/.paste[].
- introduced widget.toggle[].
- introduced sound.map[], which behaves like image.map[].
- breaking: introduced the app interface, which absorbs sys.fullscreen and sys.playing.
v1.21:
- introduced tracing paper mode.
- generalized write[] to support per-frame custom delays for GIFs.
v1.20:
- the @ operator now accepts a primitive unary operator as a left argument.
- introduced the "keys" operator.
- breaking: the x.event[] function now returns the result of the event handler function, instead of the source interface.
- breaking: the "range" operator now returns the elements of a dictionary/table/list instead of the keys. 
v1.19:
- introduced a touch-friendly UI mode including a soft keyboard.
v1.18:
- rich text attributes may now be edited directly from the field properties modal.
- added "array.cat[]".
v1.17:
- generalized go[] to accept functions as a second argument, and a frame count as a third argument.
- added move up/move down menu items for reordering widgets.
- introduced the 'C' column format: "plain currency" like "123.00".
- grids now right-align numeric columns.
v1.16:
- introduced the "ifelse" keyword to lil.
- the grid overlay now shows a simple dot-grid in full-scale mode and grid lines in FatBits.
v1.15:
- added "image.merge[]", as a parallel to "canvas.merge[]".
- if Decker detects "start.deck" in its base directory, it will be opened at startup.
v1.14:
- added "prototype.offset" and "prototype.pos" (read-only).
- added support for loading the frames of a GIF animation via the "frames" and "gray_frames" hints for read[].
v1.13:
- improved performance and framerate accuracy in web-decker.
v1.12:
- introduced Prototypes and Contraptions.
- introduced "widget.offset".
- introduced "widget.animated".
v1.11:
- introduced "sys.fullscreen".
v1.10:
- unicode curly-quotes (single and double) are now "straightened" when pasting or importing text.
- edit -> Paste as New Canvas now creates locked canvases by default.
- introduced x.event[name args...] for Deck, Card, and widget interfaces.
- breaking: deprecated card inheritance (Parent/Child cards).
- breaking: deprecated specialized "event injectors" in Lilt (superceded by x.event[]).
v1.9:
- added fullscreen mode to web-decker
- generalized Edit -> Copy Image to work for non-canvas widgets.
v1.8:
- added grid-snapping mode for drawing tools and widget manipulation.
v1.7:
- readcsv[] now allows spaces in column names.
- deck.add[] now accepts card interfaces.
- introduced bulk grid editing as JSON/CSV in the properties panel.
- F-keys can now be used to swap tools.
v1.6:
- general performance improvements while idling.
- introduced the "local" construct in Lil, to explicitly force the creation of a local variable.
v1.5:
- imported color images now support transparency correctly.
- contrast adjustment for imported color images (j/k key shortcuts).
- added "X-Ray Specs" to the script editor.
- breaking: patterns[2-27] now reads and writes custom patterns as image interfaces instead of byte-lists.
v1.4:
- introduced "sys.playing".
- introduced the "loop" event for cards.
v1.3:
- the play[] function can now be used to begin or end a looped background sound.
- Added the Edit->Resize to Card and Edit->Resize to Original menu items for manipulating box selections.
v1.2:
- The random[] function is now pre-seeded on startup.
- Queries can now define and reference columns with names that are reserved words or not valid Lil identifiers.
- Added the canvas.draggable property.
- Widget and image selections now provide orthogonal resize handles in addition to diagonal.
- Added the Edit -> Tight Selection menu item, for automatic lasso masking.
- Web-decker supports '#' URL suffixes to link to a specific card.
- Revised toolbar layout which fits better on 720p displays.
v1.1:
- Generalized the "orderby" clause of Lil queries to support lexicographic comparison of tuples.
- Generalized "canvas.merge[]" to accept a list of images as an alternative to individual images as arguments.
- Holding shift before performing a drawing operation erases, as an alternative to right-clicking on a mouse.
v1.0:
- public release.

Links
-----
binary releases: https://internet-janitor.itch.io/decker
latest documentation: http://beyondloom.com/decker
